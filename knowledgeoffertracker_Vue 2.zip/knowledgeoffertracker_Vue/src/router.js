import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

export default new VueRouter({
	mode: 'history',
	routes: [
		{
			path: '/',
			component: () => import('@/views/Home'),
			children: [
				{
					path: '/',
					component: () => import('@/views/layoutA/LayoutA'),
					children: [
						{
							path: '/',
							component: () => import('@/views/layoutA/Index'),
						},
						{
							path: '/technology',
							props: true,
							component: () => import('@/views/layoutA/Technology')
						},
						{
							path: '/business',
							props: true,
							component: () => import('@/views/layoutA/Business')
						},
						{
							path: '/user_story',
							props: true,
							component: () => import('@/views/layoutA/UserStory')
						},
						{
							path: '/others',
							props: true,
							component: () => import('@/views/layoutA/Others')
						},
						// {
						// 	path: '/search_session/:keyword?',
						// 	props: true,
						// 	component: () => import('@/views/layoutA/SessionList')
						// }
					]
				}
			]
		}
	]
})