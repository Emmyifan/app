import Mock from 'mockjs'

let data = [
  {
    id: 1,
    name: "Angular CLI====",
    action: "receive",
    learningType: "E-learn",
    date: new Date(),
    duration: 4,
    level: "entry",
    skillSource: "Pluralsight",
    attendee: "Yifan Cao"
  },
  {
    id: 2,
    name: "Angular CLI",
    action: "receive",
    learningType: "E-learn",
    date: new Date(),
    duration: 4,
    level: "entry",
    skillSource: "Pluralsight",
    attendee: "Yifan Cao"
  },
  {
    id: 3,
    name: "Angular CLI",
    action: "receive",
    learningType: "E-learn",
    date: new Date(),
    duration: 4,
    level: "entry",
    skillSource: "Pluralsight",
    attendee: "Yifan Cao"
  }
]

Mock.mock('/site/list', 'get', data)
Mock.mock('/site/delete', 'post', function (res) {
  console.log('res', res);
  const id = res.body;
  // 模拟删除，仅仅是过滤当前项
  return data.filter(item => item.id !== id);
})


Mock.mock('/site/edit', 'post', function (res) {
  console.log('res', res);
  return data;
})

Mock.mock('/site/save', 'post', function (res) {
  let newData = JSON.parse(res.body);
  let lastId = data[data.length - 1].id;
  data.push(Object.assign(newData, { id: lastId + 1 }))
  return data;
})