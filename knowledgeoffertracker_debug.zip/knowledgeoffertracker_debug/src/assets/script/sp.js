import $ from 'jquery'

// Setting global variables
var loadTrackerSP = 0;
var user = {};

// Start script
$( document ).ready(function() {
	$.getScript( "js/MicrosoftAjax.js" )
	  .done(function( script, textStatus ) {
		console.log( 'AJAX JS LOADED' );
		loadTrackerSP += 1;
		checkLoadStatusSP();
		
		// Trigger additional SP Runtime JS load
		$.getScript( "/mysite.na.xom.com/_layouts/15/sp.runtime.js" )
		  .done(function( script, textStatus ) {
			console.log( 'SP RUNTIME JS LOADED' );
			loadTrackerSP += 1;
			checkLoadStatusSP();
			
			// Trigger additional SP Runtime JS load
			$.getScript( "/mysite.na.xom.com/_layouts/15/sp.js" )
			  .done(function( script, textStatus ) {
				console.log( 'SP JS LOADED' );
				loadTrackerSP += 1;
				checkLoadStatusSP()
			  })
			  .fail(function( jqxhr, settings, exception ) {
				alert("Yikes! Something didn't work. Try again or contact your administrator.");
			});
		  })
		  .fail(function( jqxhr, settings, exception ) {
			alert("Yikes! Something didn't work. Try again or contact your administrator.");
		});
	  })
	  .fail(function( jqxhr, settings, exception ) {
		alert("Yikes! Something didn't work. Try again or contact your administrator.");
	});
});

// FUNCTIONS
function checkLoadStatusSP() {
	if(loadTrackerSP == 3) { startSP(); }
}

function startSP() {
	console.log('START SP LOGIC')
	CallClientOM();
}

//  SHAREPOINT LOGIC

function CallClientOM(){
	var context = new SP.ClientContext.get_current();
	this.website = context.get_web();
	this.currentUser = website.get_currentUser();
	context.load(currentUser);
	context.executeQueryAsync(Function.createDelegate(this, this.onQuerySucceeded), Function.createDelegate(this, this.onQueryFailed));
}

function onQuerySucceeded(sender, args)
 {
	 // Set user object
	 user.lanid = currentUser.get_loginName().substr(currentUser.get_loginName().length - 7);
	 user.name = currentUser.get_title().split(', ')[1].split(' ')[0];
	 user.email = currentUser.get_email();
	 user.login = currentUser.get_loginName().split('|')[1].replace(/\\/g, '_');
	
	console.log('Retrieved user')
 }

function onQueryFailed(sender, args)
{
alert('request failed ' + args.get_message() + '\n'+ args.get_stackTrace());
}
